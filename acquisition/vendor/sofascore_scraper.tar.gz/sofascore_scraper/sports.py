"""
Spor kayıt defteri: desteklenen sporlar ve maç detay dilimleri tek yerde.

Okuyanlar: sofascore_scraper/status.py (skor ailesi), sofascore_scraper/services/live/ (izleyici parametreleri), sofascore_scraper/services/pipeline.py
(istenecek detay uç noktaları), sofascore_scraper/web/league_sports.py (liglerin sporu),
sofascore_scraper/web/api/v1/ (GET /api/v1/sports), `ssc watch` (--sport seçenekleri), sofascore_scraper/services/planning.py
(bir maçın ihtiyacı: beklenen dilimler).

Yeni spor eklemek:
  1. SPORTS'a bir SportSpec (periyot ailesindeyse `period_format`, set ailesindeyse `set_format` ile; oyuncuları
     SofaScore'da takım olarak listelenen bireysel bir sporsa `individual=True`).
  2. Skor biçimi mevcut ailelerden (docs/all-sports/README.md, "Sınıf gerekçeleri") biri değilse
     sofascore_scraper/status.py'de yeni bir extract_scores dalı ve sofascore_scraper/schema'da yeni bir skor modeli.
  3. Spora özel detay uç noktası varsa DETAIL_SLICES'a bir satır (ya da var olan satırın `sports` kümesine ekleme);
     ortak bir dilim o sporda yoksa `not_in`, veri hep gelmiyorsa `optional_in` kümesine (DETAIL_SLICES'ın
     üstündeki kurallar; kanıt tests/fixtures/sport_slices/evidence.json'a girer).
  4. Web arayüzü listeyi ve bayrakları GET /api/v1/sports'tan okur; sporun adı frontend/src/locales/{tr,en}.ts'e
     yazılır (tests/test_sports_registry.py her kayıtlı sporun adı olduğunu denetler).

Bu modül başka hiçbir sofascore_scraper modülünü içe aktarmaz (döngüsel bağımlılık olmasın).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from typing import Any, Dict, FrozenSet, Iterable, Literal, Mapping, Optional, Tuple, Union

# Skorun biçimi (sofascore_scraper/status.py'deki ScoreSheet alt sınıfı):
#   football: devre / 90 dk / uzatma / penaltı ayrımı (FootballScores)
#   periods:  periyot toplamları, normal süre, uzatma (BasketballScores)
#   sets:     kazanılan set + set başına oyun/sayı, tie-break (TennisScores, SetsScores)
#   innings:  beyzbol: inning başına sayı (run), uzatma inning'leri, isabet ve hata toplamı (InningsScores)
#   cricket:  kriket: iki tarafın innings'leri: sayı, düşen kale, over (CricketScores)
#   fight:    skor yok; sonuç yöntemi ve son raunt (MMA; FightScores)
ScoreFamily = Literal["football", "periods", "sets", "innings", "cricket", "fight"]

# Periyot ailesinde normal sürenin bölünüşü (sofascore_scraper/status.py BasketballScores.format, şemada PeriodsScore.format):
#   quarters: dört çeyrek (period1..period4)
#   halves:   iki yarı; basketbolun iki yarılı liglerinde period2/period4, öteki sporlarda period1/period2
#   thirds:   üç periyot (period1..period3)
PeriodFormat = Literal["quarters", "halves", "thirds"]

# Set ailesinde bir setin neyle sayıldığı (sofascore_scraper/status.py SetsScores.format; plan maddesi SP-2):
#   games:  oyun; set tie-break'i ve match tie-break olabilir (padel; tenis kendi çizelgesini kullanır)
#   points: sayı (voleybol, badminton, masa tenisi); tie-break yok
#   frames: yalnızca kazanılan frame sayısı (snooker); periodN set skoru değildir
#   legs:   set başına leg (dart, set usulü maç: olayda bestOfSets > 1)
#   legs_won:  yalnızca kazanılan leg sayısı (dart, setsiz ya da tek setlik maç). Kayıt defterinde durmaz:
#              sofascore_scraper/status.py olayın bestOfSets alanı yoksa ya da 1 ise `legs`'i buna çevirir
#   games_won: kazanılan oyun (harita) sayısı (e-spor); set listesi oyun başına skordur. periodN ya oyunun skoru
#              (CS2'nin bitmiş serilerinde raunt) ya da oyunu kimin aldığı (1 / 0; canlı yük, raunt skoru vermeyen
#              oyunlar); oynanmamış oyunlar 0-0 gelir ve sayılmaz (sofascore_scraper/status.py _esports_games)
SetFormat = Literal["games", "points", "frames", "legs", "legs_won", "games_won"]

# Bitişe yakınlık kuralı (sofascore_scraper/services/live/reducer.py NEAR_END_RULES):
#   football_minute: 2. yarı ≥ 80. dk ya da uzatma dakikası görüldü; uzatma/penaltı kodları
#   played_ratio:    oynanan süre ≥ normal sürenin %90'ı; saat yoksa son periyot kodu
#   last_set:        son set (defaultPeriodCount)
#   never:           kural yok; maç sayfası yalnızca listeden düşünce ya da takılınca okunur
NearEndRule = Literal["football_minute", "played_ratio", "last_set", "never"]

# Askıya alınan maç aynı id ile ertesi güne kayabiliyor (docs/status-matrix: B9/T6, B13) → başlangıç + 4 sa
DEFAULT_STUCK_AFTER_SECONDS = 4 * 3600


@dataclass(frozen=True)
class WatcherParams:
    """Canlı izleyicinin spora göre değişen parametreleri (varsayılanlar kayıtlı olmayan spor için de geçerli)."""

    near_end_rule: NearEndRule = "never"
    # Bu kadar süre geçtiği halde bitmeyen (canlı ya da başlamamış) maç "takılı" sayılır
    stuck_after_seconds: int = DEFAULT_STUCK_AFTER_SECONDS
    # True: süre startTimestamp'ten değil gerçek oyun başlangıcından sayılır (sofascore_scraper/services/live/reducer.py play_start)
    stuck_from_play_start: bool = False


DEFAULT_WATCHER_PARAMS = WatcherParams()


@dataclass(frozen=True)
class SportSpec:
    slug: str  # SofaScore slug'ı: /sport/{slug}/..., tournament.category.sport.slug
    name: str  # SofaScore'un İngilizce adı (tournament.category.sport.name; arama sonuçlarında bu gelir)
    i18n_key: str  # web arayüzündeki ad: frontend/src/locales/{tr,en}.ts
    score_family: ScoreFamily
    watcher: WatcherParams = DEFAULT_WATCHER_PARAMS
    aliases: Tuple[str, ...] = ()  # normalize_sport için ek tam adlar (küçük harf)
    # Periyot ailesinde normal sürenin sabit bölünüşü. None: skorlardan sezilir (basketbol: çeyrek ya da iki yarı)
    period_format: Optional[PeriodFormat] = None
    # Set ailesinde setin birimi. None: tenis (2.x çizelgesi TennisScores, retired / walkover bayraklarıyla)
    set_format: Optional[SetFormat] = None
    # Bireysel spor: bir kişiye (ya da çifte) karşı bir kişi. SofaScore bu sporların oyuncularını (ve çiftlerini)
    # takım olarak listeler (`homeTeam`, `/search/all`'da `type: team`); okur için onlar oyuncudur (e2e F31).
    # GET /api/v1/sports `individual` alanıyla verir; web arayüzü böyle bir "takımı" oyuncu diye gösterir.
    individual: bool = False

    @property
    def detail_slices(self) -> Tuple[str, ...]:
        """Bu spor için istenen detay dilimlerinin anahtarları (DETAIL_SLICES sırasıyla)."""
        return tuple(s.key for s in slices_for(self.slug))


SPORTS: Tuple[SportSpec, ...] = (
    SportSpec(
        slug="football",
        name="Football",
        i18n_key="sport.football",
        score_family="football",
        watcher=WatcherParams(near_end_rule="football_minute"),
        aliases=("soccer",),
    ),
    SportSpec(
        slug="basketball",
        name="Basketball",
        i18n_key="sport.basketball",
        score_family="periods",
        watcher=WatcherParams(near_end_rule="played_ratio"),
    ),
    SportSpec(
        slug="tennis",
        name="Tennis",
        i18n_key="sport.tennis",
        score_family="sets",
        # startTimestamp planlanan saattir (aynı kortta sıra, yağmur); retro verisinde bitmiş 60 maçın 5'i
        # başlangıçtan > 4 sa sonra bitti (maks 5,46 sa). Ölçü gerçek oyun başlangıcı, eşik 6 sa.
        watcher=WatcherParams(near_end_rule="last_set", stuck_after_seconds=6 * 3600, stuck_from_play_start=True),
        individual=True,
    ),
    # --- A sınıfı, periyot tabanlı sporlar (docs/all-sports/README.md, "Sınıf gerekçeleri"; plan maddesi SP-1) ---
    # Ad: SofaScore'un tournament.category.sport.name değeri (research/all_sports/samples). Skorlar basketbolun
    # anahtarlarıyla gelir (periodN, normaltime, overtime, current); bölünüş sabittir.
    # Bitişe yakınlık: kayıtlı yüklerin çoğu ya da bir kısmı time.periodLength / totalPeriodCount / played taşıyan
    # sporlarda `played_ratio`; hiç saat verisi görülmeyenlerde (Aussie kuralları, futsal, florbol) `never`.
    SportSpec(
        slug="american-football",
        name="American football",
        i18n_key="sport.american-football",
        score_family="periods",
        period_format="quarters",
        # Bitmiş 30 maçın 1'inde son değişiklik başlangıçtan 4,05 sa sonra (research/all_sports/events)
        watcher=WatcherParams(near_end_rule="played_ratio", stuck_after_seconds=5 * 3600),
    ),
    SportSpec(
        slug="aussie-rules",
        name="Aussie rules",
        i18n_key="sport.aussie-rules",
        score_family="periods",
        period_format="quarters",
    ),
    SportSpec(
        slug="ice-hockey",
        name="Hockey",  # SofaScore buz hokeyine "Hockey" der
        i18n_key="sport.ice-hockey",
        score_family="periods",
        period_format="thirds",
        watcher=WatcherParams(near_end_rule="played_ratio"),
        aliases=("ice hockey",),
    ),
    SportSpec(
        slug="handball",
        name="Handball",
        i18n_key="sport.handball",
        score_family="periods",
        period_format="halves",
        watcher=WatcherParams(near_end_rule="played_ratio"),
    ),
    SportSpec(
        slug="rugby",
        name="Rugby",
        i18n_key="sport.rugby",
        score_family="periods",
        period_format="halves",
        watcher=WatcherParams(near_end_rule="played_ratio"),
    ),
    SportSpec(
        slug="futsal",
        name="Futsal",
        i18n_key="sport.futsal",
        score_family="periods",
        period_format="halves",
    ),
    SportSpec(
        slug="minifootball",
        name="Minifootball",
        i18n_key="sport.minifootball",
        score_family="periods",
        period_format="halves",
        watcher=WatcherParams(near_end_rule="played_ratio"),
        aliases=("mini football",),
    ),
    SportSpec(
        slug="floorball",
        name="Floorball",
        i18n_key="sport.floorball",
        score_family="periods",
        period_format="thirds",
    ),
    # --- A sınıfı, set tabanlı sporlar (docs/all-sports/README.md, "Sınıf gerekçeleri"; plan maddesi SP-2) ---
    # Skorlar tenisin anahtarlarıyla gelir: `current` kazanılan set, `periodN` o setteki sayı ya da oyun.
    # Çekilme ve hükmen galibiyet skorda bayrak değil, durumdur (04-schema-v1.md karar 10): bu sporların çizelgesi
    # (SetsScores) retired / walkover taşımaz. Bitişe yakınlık `last_set`: defaultPeriodCount, yoksa 3 set; kod
    # 8-12 (1.-5. set). Snooker'da set kodu yok (canlı kod 20 "Started"): `never`.
    SportSpec(
        slug="volleyball",
        name="Volleyball",
        i18n_key="sport.volleyball",
        score_family="sets",
        set_format="points",
        # Bitmiş 19 maçın 3'ünde son değişiklik başlangıçtan 4,2 / 4,22 / 5,17 sa sonra (research/all_sports/events)
        watcher=WatcherParams(near_end_rule="last_set", stuck_after_seconds=6 * 3600),
    ),
    SportSpec(
        slug="badminton",
        name="Badminton",
        i18n_key="sport.badminton",
        score_family="sets",
        set_format="points",
        watcher=WatcherParams(near_end_rule="last_set"),
        individual=True,
    ),
    SportSpec(
        slug="table-tennis",
        name="Table tennis",
        i18n_key="sport.table-tennis",
        score_family="sets",
        set_format="points",
        watcher=WatcherParams(near_end_rule="last_set"),
        individual=True,
    ),
    SportSpec(
        slug="padel",
        name="Padel",
        i18n_key="sport.padel",
        score_family="sets",
        set_format="games",
        # Tenis gibi sıralı kort programı: startTimestamp planlanan saattir; ölçü gerçek oyun başlangıcı, eşik 6 sa
        watcher=WatcherParams(near_end_rule="last_set", stuck_after_seconds=6 * 3600, stuck_from_play_start=True),
        individual=True,
    ),
    SportSpec(
        slug="snooker",
        name="Snooker",
        i18n_key="sport.snooker",
        score_family="sets",
        set_format="frames",
        # Uzun maçlar oturumlara bölünür; bitmiş 4 maçın birinde son değişiklik başlangıçtan 4,27 sa sonra
        watcher=WatcherParams(stuck_after_seconds=6 * 3600),
        individual=True,
    ),
    # --- B sınıfı: kendi durum ya da skor mantığı olan sporlar (docs/all-sports/README.md; plan maddesi SP-3) ---
    # Bitişe yakınlık kuralı hiçbirinde yok (`never`): inning, oyun ve raunt kodları için kural tanımlı değil.
    SportSpec(
        slug="baseball",
        name="Baseball",
        i18n_key="sport.baseball",
        score_family="innings",
        # Ölçülemedi: araştırmadaki bitmiş maçların changeTimestamp'i sonradan yapılan düzeltmelerdir. Uzatma
        # inning'leri ve yağmur arası maçı 4 saatin ötesine taşıyabildiği için eşik 6 sa.
        watcher=WatcherParams(stuck_after_seconds=6 * 3600),
    ),
    SportSpec(
        slug="cricket",
        name="Cricket",
        i18n_key="sport.cricket",
        score_family="cricket",
        # Birinci sınıf maçlar günlerce sürer; gün sonu durumu `willcontinue` (kod 141, "End of day 1") canlı
        # sayılır (sofascore_scraper/status.py). Dört günlük bir maçın son değişikliği başlangıçtan 32,6 sa sonra
        # (research/all_sports/events). Beş günlük test maçı ve aralar için eşik 6 gün.
        watcher=WatcherParams(stuck_after_seconds=6 * 86400),
    ),
    SportSpec(
        slug="esports",
        name="E-sports",  # SofaScore'un adı (research/all_sports/samples/esports)
        i18n_key="sport.esports",
        score_family="sets",
        set_format="games_won",
        # bestOf 5'e kadar seriler; araştırmada bitmiş seri yok. Eşik 6 sa.
        watcher=WatcherParams(stuck_after_seconds=6 * 3600),
    ),
    SportSpec(
        slug="darts",
        name="Darts",
        i18n_key="sport.darts",
        score_family="sets",
        # Set usulü maç (bestOfSets); setsiz maç sofascore_scraper/status.py'de `legs_won` olur. Bitmiş 9 maçın en uzunu
        # başlangıçtan 0,85 sa sonra bitti: varsayılan takılı eşiği (4 sa) yeter.
        set_format="legs",
        individual=True,
    ),
    SportSpec(
        slug="mma",
        name="Mixed Martial Arts",  # SofaScore'un adı (research/all_sports/samples/mma)
        i18n_key="sport.mma",
        score_family="fight",
        individual=True,
    ),
)

_BY_SLUG: Dict[str, SportSpec] = {s.slug: s for s in SPORTS}

# normalize_sport'un kayıt defterinden önceki eşlemesi: alt dizgi, bu sırayla. Davranış değişmesin diye
# korunuyor; tam eşleşme (slug / ad / alias) her zaman önce denenir. Bu yüzden "american-football" ve
# "minifootball" (SP-1) ile "table-tennis" (SP-2) kendi slug'larına çözülür. Yeni sporlar buraya EKLENMEZ.
_LEGACY_SUBSTRINGS: Tuple[Tuple[str, str], ...] = (
    ("basket", "basketball"),
    ("tennis", "tennis"),
    ("football", "football"),
    ("soccer", "football"),
)


def _name_key(raw: str) -> str:
    return raw.strip().lower().replace(" ", "-")


# Tam eşleşme tablosu: slug, ad ("Table tennis" → "table-tennis") ve alias'lar
_BY_EXACT_NAME: Dict[str, str] = {
    _name_key(raw): spec.slug for spec in SPORTS for raw in (spec.slug, spec.name, *spec.aliases)
}


def sport_slugs() -> Tuple[str, ...]:
    """Desteklenen sporların slug'ları, kayıt sırasıyla."""
    return tuple(s.slug for s in SPORTS)


def get_sport(slug: object) -> Optional[SportSpec]:
    """Slug'ı tam eşleşen spor; yoksa None. Serbest metin (ad, büyük harf) için önce normalize_sport."""
    return _BY_SLUG.get(slug) if isinstance(slug, str) else None


def normalize_sport(raw: object) -> Optional[str]:
    """
    SofaScore'un verdiği spor adını ya da slug'ını ("Football", "football", "Tennis") kayıtlı slug'a çevirir;
    tanınmıyorsa None.
    """
    s = str(raw or "").strip().lower()
    exact = _BY_EXACT_NAME.get(_name_key(s))
    if exact:
        return exact
    for marker, slug in _LEGACY_SUBSTRINGS:
        if marker in s and slug in _BY_SLUG:
            return slug
    return None


def event_sport_slug(event: Optional[Dict[str, Any]]) -> Optional[str]:
    """Olayın sporu: tournament.category.sport.slug (yoksa name), küçük harf. Normalize edilmez; yoksa None."""
    node: Any = event
    for key in ("tournament", "category", "sport"):
        node = node.get(key) if isinstance(node, dict) else None
    if not isinstance(node, dict):
        return None
    raw = node.get("slug") or node.get("name")
    return str(raw).lower() if raw else None


def score_family(slug: object) -> Optional[ScoreFamily]:
    spec = get_sport(slug)
    return spec.score_family if spec else None


def period_format(slug: object) -> Optional[PeriodFormat]:
    """Periyot ailesindeki sporun sabit bölünüşü; sezilen (basketbol) ya da kayıtlı olmayan sporda None."""
    spec = get_sport(slug)
    return spec.period_format if spec else None


def set_format(slug: object) -> Optional[SetFormat]:
    """Set ailesindeki sporun set birimi; tenis (kendi çizelgesi) ya da kayıtlı olmayan sporda None."""
    spec = get_sport(slug)
    return spec.set_format if spec else None


def is_individual(slug: object) -> bool:
    """Sporun oyuncuları SofaScore'da takım olarak mı listeleniyor (bireysel spor); kayıtlı olmayan sporda False."""
    spec = get_sport(slug)
    return spec.individual if spec else False


def watcher_params(slug: object) -> WatcherParams:
    """Kayıtlı olmayan spor için varsayılanlar: bitişe yakınlık kuralı yok, takılı eşiği başlangıç + 4 sa."""
    spec = get_sport(slug)
    return spec.watcher if spec else DEFAULT_WATCHER_PARAMS


# --- Dilim kayıt defteri --------------------------------------------------------------------

# Dilimin sahibi: yükü hangi varlığa aittir (docs/design/02-services.md 3.1). Bugün kayıtlı her dilim maçındır.
SliceOwner = Literal["event", "season", "tournament", "team", "player", "sport"]
# Maçın evresi: dilim hangi evrede var olabilir (yalnızca maç sahipli dilimlerde anlamlı)
Phase = Literal["pre", "live", "post"]

OWNERS: Tuple[str, ...] = ("event", "season", "tournament", "team", "player", "sport")
PHASES: Tuple[str, ...] = ("pre", "live", "post")
ALL_PHASES: FrozenSet[str] = frozenset(PHASES)
# Dilim grupları: seçimde bir dilim anahtarı yerine grup adı da yazılabilir ([defaults] slices = ["core"]).
# P28: `season` (sezon bilgisi, kupa ağacı), `leaders` (sezonun en iyi oyuncu ve takım listeleri), `players`
# (oyuncu istatistikleri). Yeni gruplar mevcut bir dilim anahtarıyla aynı adı taşımaz: aksi halde o anahtarı
# yazan bir yapılandırma yeni dilimleri de seçerdi.
GROUPS: Tuple[str, ...] = ("core", "odds", "standings", "statistics", "squads", "rankings", "live",
                           "season", "leaders", "players", "profiles")
PROVIDER_SUBS = "provider"  # subs="provider": alt anahtar yapılandırılan bahis sağlayıcısının kimliğidir
DEFAULT_ODDS_PROVIDER = "1"  # [client] odds_provider'ın varsayılanı (sofascore_scraper/config/settings.py)


@dataclass(frozen=True)
class OddsProvider:
    """
    SofaScore'un bildiği bir bahis sağlayıcısı: kimliği, SofaScore'un yazdığı adı ve ülkesi ("international" ya da
    ISO alpha-2). Sağlayıcının ülkesidir, makinenin değil: platform istemcinin konumunu saklamaz.
    """

    id: int
    name: str
    country: str


# Bilinen sağlayıcılar (B4; canlı doğrulama M20: arayüz "Bahis şirketi 1" yazıyordu). Kaynak SofaScore'un
# `/odds/providers/{cc}/web` listesidir (2026-10-09, 11 ülke; örneği research/all_sports/samples/*/
# odds-providers-cc-web__*.json, testin fixture'ı tests/fixtures/odds_providers/tr_web.json). Liste ülkeye göre
# değişir; burada yalnızca kimlik, ad ve ülke durur. Listenin bahis kuponu bağlantıları (`defaultBetSlipLink`,
# `betSlipLink`; ortaklık adresleri), renkleri ve kampanya alanları hiçbir yerde saklanmaz ve gösterilmez.
# Uygulama bu listeyi istemez: tablo elle yenilenir. Kayıtlı örnekte yalnızca 1 ve 1528 vardır; ötekiler aynı
# günün araştırma notlarındandır (1781, 1773, 2947: İngiltere, İspanya ve İtalya'nın bet365 ortaklıkları, adları
# notun ülkesiyle yazıldı). Tabloda olmayan bir kimlik (ör. oran veren ama hiçbir ülke listesinde görülmeyen 5)
# adsız kalır; arayüz "Bahis şirketi 5" yazar. 1681 ("Unbranded", AU) bir ad taşımadığı için yok.
ODDS_PROVIDERS: Tuple[OddsProvider, ...] = (
    OddsProvider(1, "bet365", "international"),  # ülke listelerindeki bet365 ortaklıklarının oran kaynağı
    OddsProvider(1528, "bet365 Türkiye", "TR"),
    OddsProvider(1169, "bet365 USA", "US"),
    OddsProvider(1781, "bet365 UK", "GB"),
    OddsProvider(1773, "bet365 Spain", "ES"),
    OddsProvider(2947, "bet365 Italy", "IT"),
    OddsProvider(2318, "Betclic France", "FR"),
    OddsProvider(2878, "Bwin France", "FR"),
    OddsProvider(2331, "bwin Spain", "ES"),
    OddsProvider(2069, "Daznbet Spain", "ES"),
    OddsProvider(645, "AdmiralBet Italy", "IT"),
    OddsProvider(814, "Sisal Italy", "IT"),
    OddsProvider(1674, "StarVegas Italy", "IT"),
    OddsProvider(1138, "Vbet Germany", "DE"),
    OddsProvider(2909, "Letsbet Germany", "DE"),
    OddsProvider(314, "1xBet India", "IN"),
    OddsProvider(712, "Melbet India", "IN"),
    OddsProvider(1123, "Parimatch India", "IN"),
    OddsProvider(326, "1xBet Nigeria", "NG"),
    OddsProvider(2084, "BetWinner Nigeria", "NG"),
    OddsProvider(2370, "MSport Nigeria", "NG"),
)
_ODDS_PROVIDER_BY_ID: Dict[int, OddsProvider] = {p.id: p for p in ODDS_PROVIDERS}


def odds_provider(provider_id: Any) -> Optional[OddsProvider]:
    """Kimliği (sayı ya da ondalık rakamlı metin; dilimin alt anahtarı metindir) bilinen sağlayıcı; yoksa None."""
    try:
        return _ODDS_PROVIDER_BY_ID.get(int(str(provider_id).strip()))
    except (TypeError, ValueError):
        return None


def odds_provider_label(provider_id: Any) -> str:
    """İnsan için ad: "bet365", tanınmayan kimlikte "Provider 5" (İngilizce; CLI ve log metni)."""
    found = odds_provider(provider_id)
    return found.name if found else f"Provider {provider_id}"


@dataclass(frozen=True)
class SliceSpec:
    """
    Bir dilimin tanımı (docs/design/02-services.md 3.1). Bugünkü bütün dilimler bir maçın /event/{id} dışındaki
    detay uç noktalarıdır; yanıt maçın kaydına `key` adıyla yazılır.

    Varsayılanlar bugünkü davranışı verir: sahibi maç, alt anahtarı yok, her evrede istenebilir (bugün hiçbir
    yol evreye bakmaz), geçmişi tutulmaz, bir kez alınır, grubu `core`, her sporda aynı tamlık kuralı.

    `not_in` ve `optional_in` tasarımdaki alanlara eklidir: aynı uç nokta bir sporda hiç yok, ötekinde her
    maçta yok olabilir; dilim anahtarı ise her sporda aynı kalır (Store'un adresi spordan bağımsızdır).
    """

    key: str  # match_data anahtarı ve dosya adı
    path: str  # API kök adresine eklenir; {event_id} yer tutucusu
    # Hangi sporlarda istenir. None: hepsinde (kayıt defterinde olmayan ya da sporu bilinmeyen maç dahil)
    sports: Optional[FrozenSet[str]] = None
    # Kullanıcı seçimi yokken istenir mi (`select_slices`, seçim None)
    default_enabled: bool = True
    # True: tamlık hesabına girer (eksikse yeniden istenir, bitmiş maçta boş gelirse "yok" sayılır), tek maç
    # indirmede de istenir ve {key}.json diskten okunur. False: yalnızca toplu indirmede, en iyi çabayla.
    # Tasarımdaki adı `counts_for_completeness` (aşağıdaki özellik); alan adı okuyucular için `required` kalır.
    required: bool = True
    owner: SliceOwner = "event"
    # Alt anahtarlar: None = yok (""), bir demet (ör. ("total", "home", "away")) ya da "provider"
    subs: Union[Tuple[str, ...], Literal["provider"], None] = None
    phases: FrozenSet[str] = ALL_PHASES
    group: str = "core"
    keep_history: bool = False  # değişen yük dilimin geçmişine eklenir (ör. oranlar)
    max_age: Optional[timedelta] = None  # sahibi maç olmayan dilimde: bundan eskiyse yeniden alınır (None = bir kez)
    # SofaScore'un bu dilimi sunmadığı sporlar: orada hiç istenmez (`sports` None iken de). Kanıt:
    # DETAIL_SLICES'ın üstündeki not
    not_in: FrozenSet[str] = frozenset()
    # Dilimin istendiği ama tamlık hesabına girmediği sporlar (`required` True iken): orada veri hep gelmiyor
    optional_in: FrozenSet[str] = frozenset()
    # Yanıtta verinin durduğu üst anahtar (P28'in dilimleri): gövde bir nesne ve bu anahtarın değeri doluysa veri
    # var. None: sofascore_scraper/slices.py'deki kural (kuralı yoksa gövdenin dolu olması yeter)
    body_key: Optional[str] = None
    # Uç noktanın yanıt biçimi yalnızca katalogdan (docs/all-sports/endpoints.csv) biliniyor, kayıtlı örneği
    # yok ya da örnek 404: canlı doğrulamaya kadar deneysel (docs'ta "needs live validation")
    experimental: bool = False

    def __post_init__(self) -> None:
        if self.owner not in OWNERS:
            raise ValueError(f"slice {self.key!r}: owner must be one of {', '.join(OWNERS)}, got {self.owner!r}")
        if not self.phases or not set(self.phases) <= ALL_PHASES:
            raise ValueError(f"slice {self.key!r}: phases must be a non-empty subset of {', '.join(PHASES)}")
        if self.group not in GROUPS:
            raise ValueError(f"slice {self.key!r}: group must be one of {', '.join(GROUPS)}, got {self.group!r}")
        if not (self.subs is None or self.subs == PROVIDER_SUBS
                or (isinstance(self.subs, tuple) and self.subs and all(isinstance(s, str) and s for s in self.subs))):
            raise ValueError(f"slice {self.key!r}: subs must be None, 'provider' or a tuple of names")
        if self.not_in & self.optional_in:
            raise ValueError(f"slice {self.key!r}: a sport cannot be in both not_in and optional_in")
        if self.optional_in and not self.required:
            raise ValueError(f"slice {self.key!r}: optional_in needs a required slice")
        if self.sports is not None and not (self.not_in | self.optional_in) <= self.sports:
            raise ValueError(f"slice {self.key!r}: not_in and optional_in must be subsets of sports")
        if (self.subs is None) == ("{sub}" in self.path):
            raise ValueError(f"slice {self.key!r}: a slice with subs has {{sub}} in its path, one without has not")
        if self.max_age is not None and self.max_age.total_seconds() <= 0:
            raise ValueError(f"slice {self.key!r}: max_age must be positive")

    def sub_keys(self, provider: Optional[str] = None) -> Tuple[str, ...]:
        """
        Dilimin alt anahtarları: alt anahtarı yoksa (""), sabit bir demetse o demet, "provider" ise yapılandırılan
        bahis sağlayıcısının kimliği (verilmezse DEFAULT_ODDS_PROVIDER; Store alt anahtarı ondalık rakamlardır).
        """
        if self.subs is None:
            return ("",)
        if self.subs == PROVIDER_SUBS:
            return (str(provider or DEFAULT_ODDS_PROVIDER),)
        return tuple(self.subs)

    def format_path(self, sub: str = "", **ids: object) -> str:
        """
        Dilimin API yolu (köke göre): yer tutucular `ids`'ten (event_id, tournament_id, season_id, team_id,
        player_id) ve `sub`'dan doldurulur. Sahibinin bir kimliği eksikse KeyError.
        """
        return self.path.format(sub=sub, **ids)

    @property
    def counts_for_completeness(self) -> bool:
        """
        Tasarımdaki ad: `required`. Spordan bağımsız varsayılandır (sporu bilinmeyen maç ve `optional_in`'de
        olmayan her spor); bir sporun maçı için `counts_in(spor)`.
        """
        return self.required

    def applies_to(self, sport: Optional[str]) -> bool:
        return (self.sports is None or sport in self.sports) and sport not in self.not_in

    def counts_in(self, sport: Optional[str]) -> bool:
        """Bu spordaki bir maçta tamlık hesabına girer mi (dilim o sporda istenmiyorsa hayır)."""
        return self.required and self.applies_to(sport) and sport not in self.optional_in

    def valid_in(self, phase: Optional[str]) -> bool:
        """Dilim bu evrede var olabilir mi; evre bilinmiyorsa (None) evet."""
        return phase is None or phase in self.phases

    def url(self, base_url: str, event_id: object) -> str:
        return base_url + self.path.format(event_id=event_id)


# Eski ad: bugünkü bütün dilimler maç detayıdır
DetailSlice = SliceSpec


# Her sporun dilimleri, sitenin maç sayfasının istediklerinden (research/all_sports: PR #17'nin keşfi ve onarılmış
# keşif aracının koşusu lv-20261009, PR #183; kurallar tests/sport_evidence.py'de):
#   * bitmiş maçta veriyle yanıtlanan ve bitmiş maçta hiç 404 almayan dilim tamlık hesabına girer (`required`);
#   * başlamış (canlı ya da bitmiş) bir maçta 404 alan, bitmiş maçta verisi görülmeyen dilim istenir ama tamlık
#     hesabına girmez (`optional_in`): eksik kalınca maç yeniden doldurulmaz;
#   * sayfa açılınca istenen bir dilim (istatistik, kadro, olaylar) o sporun eksiksiz yüklenmiş canlı ya da
#     bitmiş maç sayfasında hiç istenmediyse o sporda istenmez (`not_in`). Eksiksiz: sayfa /event/{id}'yi ve
#     /event/{id}/pregame-form'u istedi. Yokluk yalnızca onarılmış koşunun sayfalarından okunur (eski araç
#     istekleri kaybediyordu). H2H ve seriler bitmiş maçta ayrı sekmededir: sekmesi açılmayan sporda yokluk
#     kanıt sayılmaz;
#   * hiçbir başlamamış maç sayfasının istemediği ya da orada yalnızca 404 alan dilim maç başlayınca vardır
#     (`phases` canlı ve bitmiş). Canlı maçta yokluk evreyi daraltmaz (canlı kanıt az);
#   * kanıt yoksa ya da yetersizse (sayfası açılmamış, 403 almış ya da yalnızca başlamamış maçı olan sporlar)
#     bugünkü davranış kalır.
# Futbol, basketbol ve tenis için kanıtın önerdikleri (#121) canlı doğrulamadan sonra sahibin kararıyla
# uygulandı (FX-16, 2026-10-08): üçünde pregame_form isteğe bağlı; teniste kadro ve olaylar istenmez,
# point_by_point tamlığa girer. Uygulama tarafı kanıt: tests/fixtures/sport_slices/slice-matrix-*.txt.
# Ragbi, voleybol, florbol ve mini futbolda FX-31'in önerisi, en çok takip edilen üç ligin bitmiş maçlarıyla
# (lv-20261009b) yeniden bakıldıktan sonra sahibin kararıyla uygulandı (FX-36, 2026-10-09): ragbi ve voleybolda
# istatistik, kadro, olaylar ve pregame_form isteğe bağlı; florbolda kadro istenmez, istatistik ve pregame_form
# isteğe bağlı, olaylar tamlığa girer (kanıtın kuralı bir bitmiş maçtaki 404'ten isteğe bağlı der; üst liglerin üç
# maçında veriyle); mini futbolda istatistik, olaylar ve pregame_form isteğe bağlı (kadro zaten öyleydi).
# tests/test_sport_slices.py DECIDED, docs/all-sports/README.md "Karar".
# Kanıt tablosu: tests/fixtures/sport_slices/evidence.json (research/all_sports'tan türer; testler denetler).
#
# Sıra önemli: istek sırası ve DETAIL_SLICE_KEYS / REQUIRED_FILES sırası buradan türer
DETAIL_SLICES: Tuple[SliceSpec, ...] = (
    # Kriket, futsal, padel: bitmiş maçta 404. E-spor, snooker: canlı maçta 404. Ragbi, voleybol, florbol, mini
    # futbol: bitmiş maçların bir kısmında ya da hepsinde 404 (FX-36). Başlamamış maçın sayfası istemiyor
    # (lv-20261009: 15 sporun başlamamış 15 maçı): maç başlayınca vardır
    SliceSpec("statistics", "/event/{event_id}/statistics",
              optional_in=frozenset({"cricket", "futsal", "padel", "esports", "snooker", "rugby", "volleyball",
                                     "floorball", "minifootball"}),
              phases=frozenset({"live", "post"})),
    SliceSpec("team_streaks", "/event/{event_id}/team-streaks"),
    # Bitmiş maçta 404: Amerikan futbolu, badminton, beyzbol, kriket, dart, futsal, padel, masa tenisi. Canlı
    # maçta 404: beyzbol, e-spor, snooker. Buz hokeyi ve MMA'da bir bitmiş maçta veriyle, ötekinde 404. Futbol,
    # basketbol, tenis: #121'in bütün bitmiş maçlarında 404 (futbolun lv-20261009'daki iki bitmiş maçında
    # veriyle); canlı doğrulamada (2026-10-08) bazı maçta veriyle, bazısında veri yok (FX-16). Ragbi, florbol:
    # bitmiş maçların bir kısmında 404; voleybol, mini futbol: bütün bitmiş maçlarda 404 (FX-36)
    SliceSpec("pregame_form", "/event/{event_id}/pregame-form",
              optional_in=frozenset({"american-football", "badminton", "baseball", "basketball", "cricket", "darts",
                                     "football", "futsal", "ice-hockey", "mma", "padel", "esports", "snooker",
                                     "table-tennis", "tennis", "rugby", "volleyball", "floorball",
                                     "minifootball"})),
    SliceSpec("h2h", "/event/{event_id}/h2h"),
    # Bireysel sporların sayfası kadro istemiyor (badminton, dart, MMA, padel, snooker, masa tenisi, tenis);
    # florbolun sayfası da istemiyor (eksiksiz bitmiş ve başlamamış sayfalar; FX-36). Futsal ve mini futbolda
    # bitmiş maçta 404; ragbide bitmiş maçların bir kısmında, voleybolda hepsinde 404 (FX-36)
    SliceSpec("lineups", "/event/{event_id}/lineups",
              not_in=frozenset({"badminton", "darts", "mma", "padel", "snooker", "table-tennis", "tennis",
                                "floorball"}),
              optional_in=frozenset({"futsal", "minifootball", "rugby", "volleyball"})),
    # Beyzbolun sayfası olayları istemiyor (iki bitmiş ve bir canlı maç). Futsal, ragbi, voleybol, mini futbol: bir
    # kısım bitmiş maçta veriyle, ötekilerde 404 (FX-36). Florbolda bir bitmiş maçta 404 ama sahibin kararıyla
    # tamlığa girer (FX-36: üst liglerin üç bitmiş maçında veriyle)
    SliceSpec("incidents", "/event/{event_id}/incidents",
              not_in=frozenset({"baseball", "darts", "esports", "mma", "padel", "snooker", "tennis"}),
              optional_in=frozenset({"futsal", "rugby", "volleyball", "minifootball"})),
    # Tenis, dart, badminton, masa tenisi: set, oyun (dartta leg) başına sayılar; bitmiş maçta veriyle
    # (research/all_sports/samples/{darts,badminton,table-tennis}; tenis için canlı doğrulama da, 2026-10-08,
    # FX-16). Başlamamış tenis, badminton ve masa tenisi maçında 404: maç başlayınca vardır
    SliceSpec("point_by_point", "/event/{event_id}/point-by-point",
              sports=frozenset({"tennis", "darts", "badminton", "table-tennis"}), phases=frozenset({"live", "post"})),
    # E-sporda her oyunun (haritanın) durumu, kazananı ve yarı skorları (SP-3). Oyun nesneleri maç olarak
    # dizinlenmez: yanıt maçın bir dilimidir. Oyunlar maç başlayınca vardır (başlamamış maçta 404); canlı ve
    # bitmiş maçta veriyle (research/all_sports/samples/esports): tamlığa girer
    SliceSpec("esports_games", "/event/{event_id}/esports-games", sports=frozenset({"esports"}),
              phases=frozenset({"live", "post"})),
    # Kriketin skor kartı: her innings'in vuran ve atan takımı, sayı, düşen kale, over ve ekstralar. Maç
    # başlayınca vardır (başlamamış maçta 404); bitmiş maçta veriyle (research/all_sports/samples/cricket)
    SliceSpec("innings", "/event/{event_id}/innings", sports=frozenset({"cricket"}),
              phases=frozenset({"live", "post"})),
)


# --- P28: bahis oranları ve maç dışı veriler ------------------------------------------------------------
#
# Hepsi varsayılan olarak kapalıdır (`default_enabled=False`) ve tamlık hesabına girmez (`required=False`): adı
# ya da grubu bir seçimde ([defaults] slices, [slices.<spor>], takibin `slices`'ı) geçmedikçe hiç istenmez.
# Uç noktalar docs/all-sports/endpoints.csv'den; yanıt örnekleri research/all_sports/samples altında. Örneği
# olmayan ya da örneği 404 olan dilim `experimental`dır (canlı doğrulama projenin sonunda).
#
# Bahis oranları (grup `odds`): alt anahtar yapılandırılan sağlayıcının kimliğidir ([client] odds_provider;
# kayıtlı örneklerin hepsi sağlayıcı 1, girişsiz). Hangi sağlayıcının döndüğü SofaScore'da ülke koduna bağlıdır;
# dilimin `meta`sı isteğin sağlayıcısını kaydeder (istemcinin IP'si ya da konumu saklanmaz). Tek bir okuma bir
# anlık görüntüdür: değişen yük dilimin geçmişine eklenir (`keep_history`). Maç başlamadan önce her eşitlemede
# `max_age`'den eskiyse yeniden okunur, maç bittikten sonra bir kez daha (sofascore_scraper/services/planning.py).
ODDS_MAX_AGE = timedelta(minutes=30)

ODDS_SLICES: Tuple[SliceSpec, ...] = (
    # Öne çıkan pazar (maç sonucu): {"featured": {"default": market, "fullTime": market, ...}}
    SliceSpec("odds_featured", "/event/{event_id}/odds/{sub}/featured", subs=PROVIDER_SUBS, group="odds",
              default_enabled=False, required=False, keep_history=True, max_age=ODDS_MAX_AGE, body_key="featured"),
    # Bütün pazarlar: {"markets": [market, ...], "eventId": ...}
    SliceSpec("odds_all", "/event/{event_id}/odds/{sub}/all", subs=PROVIDER_SUBS, group="odds",
              default_enabled=False, required=False, keep_history=True, max_age=ODDS_MAX_AGE, body_key="markets"),
    # Maç sonucu oranlarının zaman çizelgesi: {"changedOdds": [{"timestamp", "choice1", ...}]}
    SliceSpec("odds_changes", "/event/{event_id}/odds/{sub}/changes", subs=PROVIDER_SUBS, group="odds",
              default_enabled=False, required=False, keep_history=True, max_age=ODDS_MAX_AGE,
              body_key="changedOdds"),
    # Oranlara göre beklenen ve gerçekleşen kazanma oranı: {"home": null | {"fractionalValue", "expected", "actual",
    # "id"}, "away": {...}}. Bir taraf null olabilir; biçim canlı doğrulamada görüldü (2026-10-08, FX-27). Gövdenin
    # kuralı sofascore_scraper/services/pipeline.py `body_state`; şemanın Odds kaydına girmez, ham kalır
    SliceSpec("winning_odds", "/event/{event_id}/provider/{sub}/winning-odds", subs=PROVIDER_SUBS, group="odds",
              default_enabled=False, required=False, keep_history=True, max_age=ODDS_MAX_AGE),
)

# Maç dışı dilimler: sahibi sezon, takım, oyuncu ya da spordur. Planlayıcı sahip başına bir iş birimi üretir
# (sofascore_scraper/services/planning.py `owner_items`); `max_age`'den eski dilim yeniden okunur.
_SEASON = "/unique-tournament/{tournament_id}/season/{season_id}"

OWNER_SLICES: Tuple[SliceSpec, ...] = (
    # Puan durumu: {"standings": [{"type", "name", "rows": [...]}]}. `home` alt anahtarının örneği yok
    SliceSpec("standings", _SEASON + "/standings/{sub}", owner="season", subs=("total", "home"),
              group="standings", default_enabled=False, required=False, max_age=timedelta(hours=6),
              body_key="standings"),
    SliceSpec("season_info", _SEASON + "/info", owner="season", group="season", default_enabled=False,
              required=False, max_age=timedelta(days=7), body_key="info"),
    # Kupa ağacı (eleme turları): {"cupTrees": [...]}
    SliceSpec("cuptrees", _SEASON + "/cuptrees", owner="season", group="season", default_enabled=False,
              required=False, max_age=timedelta(hours=12), body_key="cupTrees"),
    # Sezonun en iyi oyuncuları ve takımları (istatistik türüne göre listeler); yalnızca futbolda görüldü
    SliceSpec("top_players", _SEASON + "/top-players/overall", owner="season", group="leaders",
              sports=frozenset({"football"}), default_enabled=False, required=False, max_age=timedelta(days=1),
              body_key="topPlayers"),
    SliceSpec("top_teams", _SEASON + "/top-teams/overall", owner="season", group="leaders",
              sports=frozenset({"football"}), default_enabled=False, required=False, max_age=timedelta(days=1),
              body_key="topTeams"),
    # Sezonun uzun vadeli oranları (şampiyon, küme düşme). Tek kayıtlı örnek 404
    SliceSpec("season_odds", "/odds/season/{season_id}/provider/{sub}/all", owner="season", subs=PROVIDER_SUBS,
              group="odds", sports=frozenset({"football"}), default_enabled=False, required=False,
              keep_history=True, max_age=timedelta(hours=6), body_key="markets", experimental=True),
    # Tenisçinin sıralamaları (ATP/WTA, canlı sıralama, UTR): {"rankings": [...]}
    SliceSpec("team_rankings", "/team/{team_id}/rankings", owner="team", group="rankings",
              sports=frozenset({"tennis"}), default_enabled=False, required=False, max_age=timedelta(days=1),
              body_key="rankings"),
    # Oyuncunun sezon istatistikleri; yalnızca katalogda (örnek yok). Sahibi takip edilen oyunculardır
    SliceSpec("player_statistics", "/player/{player_id}/statistics/seasons", owner="player", group="players",
              default_enabled=False, required=False, max_age=timedelta(days=1), experimental=True),
    # Oyuncunun kişisel fişi: {"player": {ad, mevki, ülke, doğum tarihi, boy, tercih ettiği ayak, ...}}. Yalnızca
    # adı verilen oyuncular için açıkça istenir (`ssc fetch player`): takip kurmaz, maç indirmez; kendi grubu
    # (`profiles`) takip edilen oyuncuların `players` seçimine girmesin diye ayrıdır. Bir kez okunur; yeniden
    # okuma (`--refresh`) değişen yükü geçmişine ekler.
    SliceSpec("player_profile", "/player/{player_id}", owner="player", group="profiles",
              default_enabled=False, required=False, keep_history=True, body_key="player"),
    # Sporun sıralama listesi; alt anahtar sıralama türü: 5 ATP, 6 WTA (canlı doğrulama 2026-10-08: /rankings/5
    # Sinner'le, /rankings/6 Rybakina ile başlıyor; FX-27 V8). Gövdesinin kaydedilmiş örneği yok
    SliceSpec("rankings", "/rankings/{sub}", owner="sport", subs=("5", "6"), group="rankings",
              sports=frozenset({"tennis"}), default_enabled=False, required=False, max_age=timedelta(days=1),
              body_key="rankings", experimental=True),
)


def registered_slices() -> Tuple[SliceSpec, ...]:
    """
    Kayıt defterinin bütün dilimleri, tablo sırasıyla: maç detayları (DETAIL_SLICES), bahis oranları, maç dışı
    dilimler. Tablolar çağrı anında okunur (testler onları değiştirebilir).
    """
    return DETAIL_SLICES + ODDS_SLICES + OWNER_SLICES


def get_slice(key: str) -> Optional[SliceSpec]:
    return next((s for s in registered_slices() if s.key == key), None)


class UnknownSliceName(ValueError):
    """Seçimde kayıt defterinde olmayan bir ad (ne dilim anahtarı ne grup adı)."""

    def __init__(self, name: str, known: Tuple[str, ...]) -> None:
        super().__init__(f"unknown slice or slice group {name!r}; expected one of {', '.join(known)}")
        self.name = name
        self.known = known


@dataclass(frozen=True)
class SliceSelection:
    """
    Kullanıcının dilim seçimi, katmanları çözülmüş halde (02-services.md 3.1: takibin `slices`'ı →
    `[slices.<spor>]` → `[defaults] slices` → kayıt defterinin `default_enabled`'ı). Adlar dilim anahtarı ya da
    grup adıdır; grup adı o gruptaki bütün dilimleri seçer. Bir ad hem anahtar hem grup olabilir (tasarımda
    `statistics` ikisi de): o zaman ikisini de seçer.

    base: None = kayıt defterinin `default_enabled` dilimleri; bir demet = yalnızca bu adlar.
    enable / disable: tabana eklenen ve tabandan çıkarılan adlar (disable sonra uygulanır).
    layers: enable / disable'dan sonra sırayla uygulanan (ekle, çıkar) çiftleri; sonraki katman öncekini ezer
    (`resolve_selection`: önce sporun, sonra takibin farkı). Bir katmanın içinde de çıkarma sonra uygulanır.
    """

    base: Optional[Tuple[str, ...]] = None
    enable: Tuple[str, ...] = ()
    disable: Tuple[str, ...] = ()
    layers: Tuple[Tuple[Tuple[str, ...], Tuple[str, ...]], ...] = ()

    def names(self) -> Tuple[str, ...]:
        """Seçimde geçen bütün adlar (denetim için)."""
        out: Tuple[str, ...] = (*(self.base or ()), *self.enable, *self.disable)
        for enable, disable in self.layers:
            out += (*enable, *disable)
        return out


def known_slice_names() -> Tuple[str, ...]:
    """Seçimde geçerli adlar: kayıtlı dilim anahtarları (tablo sırasıyla), sonra öteki grup adları."""
    keys = tuple(s.key for s in registered_slices())
    return keys + tuple(group for group in GROUPS if group not in keys)


def check_slice_names(names: Iterable[str]) -> None:
    """Her ad bir dilim anahtarı ya da grup adı olmalı; değilse UnknownSliceName (ilk bilinmeyen ad)."""
    known = known_slice_names()
    for name in names:
        if name not in known:
            raise UnknownSliceName(str(name), known)


# Takibin `slices` alanının biçimleri (sofascore_scraper/config/settings.py FollowSpec, follows.slices_json):
#   {"include": [...]}                  yalnızca bu adlar
#   {"enable": [...], "disable": [...]} varsayılan seçime (sporun farkı dahil) göre fark
FOLLOW_SLICE_KEYS: Tuple[str, ...] = ("include", "enable", "disable")


def follow_slices(value: Any) -> Optional[Dict[str, Tuple[str, ...]]]:
    """
    Takibin `slices` değerini denetler ve olağan biçimine çevirir: None, {"include": (...)} ya da
    {"enable": (...), "disable": (...)}. Bir ad listesi {"include": ...} sayılır. Biçim bozuksa ValueError,
    bilinmeyen ad UnknownSliceName (o da bir ValueError).
    """
    if value is None:
        return None
    if isinstance(value, (list, tuple)):
        value = {"include": list(value)}
    if not isinstance(value, Mapping):
        raise ValueError('slices: expected null, a list of slice names, {"include": [...]} or '
                         '{"enable": [...], "disable": [...]}')
    unknown = sorted(str(key) for key in value if key not in FOLLOW_SLICE_KEYS)
    if unknown:
        raise ValueError(f"slices: unknown key {unknown[0]!r}; expected include, or enable and disable")
    if "include" in value and ("enable" in value or "disable" in value):
        raise ValueError("slices: give include, or enable and disable, not both")
    out: Dict[str, Tuple[str, ...]] = {}
    for key in FOLLOW_SLICE_KEYS:
        if key not in value:
            continue
        names = value[key] if value[key] is not None else []
        if isinstance(names, str) or not isinstance(names, (list, tuple)) \
                or not all(isinstance(name, str) and name.strip() for name in names):
            raise ValueError(f"slices.{key}: expected a list of slice names")
        out[key] = tuple(dict.fromkeys(name.strip() for name in names))
    if "include" not in out:
        out = {"enable": out.get("enable", ()), "disable": out.get("disable", ())}
    check_slice_names(name for names in out.values() for name in names)
    return out


def resolve_selection(defaults: Optional[Iterable[str]] = None, *, sport_enable: Iterable[str] = (),
                      sport_disable: Iterable[str] = (), follow: Any = None) -> SliceSelection:
    """
    Katmanları tek bir seçime çevirir (02-services.md 3.1; P12'nin eşlemesi):

      takibin {"include": [...]}       → base; sporun farkı ve varsayılanlar uygulanmaz (yalnızca bu adlar)
      [defaults] slices                → base (None: kayıt defterinin `default_enabled`'ı)
      [slices.<spor>] enable / disable → ilk katman
      takibin enable / disable         → ikinci katman (sporun farkını ezer)

    Adlar denetlenir: bilinmeyen ad UnknownSliceName; takibin biçimi bozuksa ValueError.
    """
    resolved = follow_slices(follow)
    if resolved is not None and "include" in resolved:
        selection = SliceSelection(base=resolved["include"])
    else:
        layers = [(tuple(sport_enable), tuple(sport_disable))]
        if resolved is not None:
            layers.append((resolved["enable"], resolved["disable"]))
        selection = SliceSelection(base=tuple(defaults) if defaults is not None else None,
                                   layers=tuple(layer for layer in layers if layer[0] or layer[1]))
    check_slice_names(selection.names())
    return selection


def _named(spec: SliceSpec, names: Iterable[str]) -> bool:
    return any(name == spec.key or name == spec.group for name in names)


def select_slices(
    owner: str,
    sport: Optional[str],
    selection: Union[SliceSelection, Iterable[str], None] = None,
    *,
    phase: Optional[str] = None,
) -> Tuple[SliceSpec, ...]:
    """
    Bir sahibin ("event", "season", "team", "player", "sport") bu sporda istenecek dilimleri, tablo sırasıyla.
    Sahibi maç olmayan dilimde `phase` anlamsızdır (dilimlerin evresi hep üçüdür).

    sport: olayın küçük harfli slug'ı (event_sport_slug); kayıt defterinde olmayan ya da bilinmeyen (None / "")
    spor yalnızca her sporda geçerli dilimleri alır. selection: None = kayıt defterinin varsayılanları; bir ad
    listesi = `SliceSelection(base=...)`. Bilinmeyen ad UnknownSliceName'dir (yapılandırmadaki adlar burada
    denetlenir). phase: verilirse yalnızca o evrede var olabilen dilimler.

    Dilim seçiminin tek geçtiği yer burasıdır; `slices_for` buna devreder.
    """
    if owner not in OWNERS:
        raise ValueError(f"owner must be one of {', '.join(OWNERS)}, got {owner!r}")
    if phase is not None and phase not in PHASES:
        raise ValueError(f"phase must be one of {', '.join(PHASES)} or None, got {phase!r}")
    if selection is not None and not isinstance(selection, SliceSelection):
        if isinstance(selection, str):
            raise ValueError("selection: expected a list of slice names, got a single string")
        selection = SliceSelection(base=tuple(selection))
    if selection is not None:
        check_slice_names(selection.names())

    return tuple(
        s for s in registered_slices()
        if s.owner == owner and s.applies_to(sport) and s.valid_in(phase) and _selected(s, selection)
    )


def _selected(spec: SliceSpec, selection: Optional[SliceSelection]) -> bool:
    if selection is None:
        return spec.default_enabled
    chosen = spec.default_enabled if selection.base is None else _named(spec, selection.base)
    if _named(spec, selection.enable):
        chosen = True
    if _named(spec, selection.disable):
        chosen = False
    for enable, disable in selection.layers:
        if _named(spec, enable):
            chosen = True
        if _named(spec, disable):
            chosen = False
    return chosen


def chosen_slices(selection: Union[SliceSelection, Iterable[str], None] = None) -> Tuple[SliceSpec, ...]:
    """Seçimin seçtiği bütün dilimler, sahibine, sporuna ve evresine bakılmadan (tablo sırasıyla)."""
    if selection is not None and not isinstance(selection, SliceSelection):
        if isinstance(selection, str):
            raise ValueError("selection: expected a list of slice names, got a single string")
        selection = SliceSelection(base=tuple(selection))
    if selection is not None:
        check_slice_names(selection.names())
    return tuple(s for s in registered_slices() if _selected(s, selection))


def slices_for(sport: Optional[str], required_only: bool = False) -> Tuple[SliceSpec, ...]:
    """
    Bu spordaki bir maç için istenecek dilimler, tablo sırasıyla (kayıt defterinin varsayılan seçimi;
    `select_slices("event", sport)`). `sport` olayın küçük harfli slug'ıdır (event_sport_slug); kayıt
    defterinde olmayan ya da bilinmeyen (None / "") spor yalnızca her sporda geçerli dilimleri alır.
    required_only: yalnızca bu sporda tamlık hesabına girenler (`counts_in`).
    """
    return tuple(s for s in select_slices("event", sport) if s.counts_in(sport) or not required_only)

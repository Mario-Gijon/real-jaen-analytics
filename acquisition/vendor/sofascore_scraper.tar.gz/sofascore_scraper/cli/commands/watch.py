"""
`watch`: canlı servisi ön planda çalıştırır (docs/design/02-services.md bölüm 8.4). systemd ya da bir konteyner
için tek süreçtir; Ctrl+C ya da SIGTERM ile durur.

    ssc watch                                      takiplerden (live = true), bütün sporlar
    ssc watch --sport football                     yalnızca futbol takipleri
    ssc watch --sport football --tournament 17     takipler yerine bu turnuvanın canlı maçları
    ssc watch --sport tennis --event 12345678      takipler yerine bu maç; bitince komut da biter
    ssc watch --stdout                             yeni olayları stdout'a da yaz (NDJSON, `sofascore.event/1`)
    ssc watch --idle                               izlenecek takip yoksa da çalış; takipler 60 sn'de bir okunur

  * İzlenecek bir şey yoksa (canlı takip yok, `--event` / `--tournament` verilmedi) komut kullanım hatasıyla
    (çıkış kodu 2) çıkar. `--idle` ile çıkmaz: bir log satırı yazar ve servis takipleri her yeniden okuyuşunda
    (SCOPE_RELOAD_SECONDS, 60 sn) bakar; `live = true` bir takip eklenince izlemeye başlar. Konteynerin ve
    systemd biriminin servisi bunu kullanır: takip yokken yeniden başlatma döngüsüne girmez.

  * Aynı veri dizininde tek canlı servis çalışır: ikincisi, biri çalışırken `instance_running` ile çıkar (çıkış
    kodu 6).
  * Kaynak `--source` ya da `[live] source`'tur. `page` (varsayılan): izlenen her spor için gerçek bir tarayıcı
    sayfası açık kalır (kendi profili, `<profil>-live`; sayfa başına yaklaşık 1,8–2,6 GB bellek) ve sayfanın
    push bağlantısının kareleri dinlenir; olaylar değişiklikten yaklaşık bir saniye sonra gelir. Yoklama her
    zaman yedektir: push sağlıklıyken yavaş aralıkla, kopuk ya da sessizken `poll_interval` ile. `poll`:
    yalnızca yoklama, tarayıcı açılmaz. `direct` (açık seçim, 8.3): hafif bir istemci push sunucusuna kendisi
    bağlanır (yaklaşık 0,2 GB); kimlik bilgisi köprü sayfasının kendi bağlantısından okunur ve yalnızca bellekte
    tutulur. Yalnızca `--source direct`, `[live] source = "direct"` ya da `SOFASCORE_LIVE__SOURCE=direct` ile
    kullanılır, hiçbir zaman kendiliğinden seçilmez; dört uyarısı (settings.LIVE_DIRECT_WARNING) `--help`'te,
    çıktıda ve her başlangıçta log'da yazılır. Her kaynağın yedeği yoklamadır; `page` çalışmazsa servis yoklamaya
    düşer, `direct`'e asla.
  * Yapılandırılmış sink'ler (`[[sink]]`, `SOFASCORE_SINKS`) bu süreçte, ayrı bir thread'de dağıtılır
    (`sinks` kilidi başka bir süreçteyse, örneğin `serve`, o dağıtır). `--stdout` kendi thread'inde, kilitsiz ve
    "şimdi"den yazar. İkisi ayrı thread'lerdir: stdout'u okuyan durursa yapılandırılmış sink'ler beklemez.
    Yapılandırılmış sink'ler ise tek thread'i paylaşır: `deliver`'ı hiç dönmeyen bir sink (asılı bir ağ dosya
    sistemi) diğerlerini bekletir. Kapanış bunu beklemez: thread'ler arka plandadır ve süre sınırıyla beklenir.
  * Canlı verinin HTTP uç noktası yoktur (sahip kararı, 2026-10-01): olaylar günlüğe ve sink'lere gider,
    sonradan `ssc events` ile okunur.

Ağır içe aktarmalar (ayarlar, Store, istek katmanı, sink'ler) işlevin içindedir (sofascore_scraper/cli/commands/__init__.py).
"""
from __future__ import annotations

import argparse
import logging
import os
import signal
import threading
from typing import Any, Dict, List, Optional

from sofascore_scraper.cli.commands import CliWarning, CommandResult, Invocation, command
from sofascore_scraper.cli.output import JSON, TEXT, Translator
from sofascore_scraper.errors import UsageError

logger = logging.getLogger(__name__)

SOURCES = ("page", "direct", "poll")
SINK_JOIN_SECONDS = 15.0  # dağıtıcı dururken birikenleri en çok 10 sn teslim eder; üstüne pay
STDOUT_JOIN_SECONDS = 5.0
# Testlerin LiveService'e verdiği ek seçenekler (sahte istek işlevi, saat, sahte sayfa açıcı); uygulama boş bırakır
SERVICE_OPTIONS: Dict[str, Any] = {}


def _hours(value: str) -> float:
    try:
        number = float(value)
    except ValueError:
        number = 0.0
    if not number > 0:
        raise argparse.ArgumentTypeError(f"expected a number of hours above 0, got {value!r}")
    return number


def _arguments(parser: argparse.ArgumentParser, t: Translator) -> None:
    parser.add_argument("--sport", dest="sports", action="append", metavar="SPORT", help=t("ssc_help_watch_sport"))
    parser.add_argument("--event", dest="event_ids", action="append", type=int, metavar="ID",
                        help=t("ssc_help_watch_event"))
    parser.add_argument("--tournament", dest="tournament_ids", action="append", type=int, metavar="ID",
                        help=t("ssc_help_watch_tournament"))
    parser.add_argument("--source", choices=SOURCES, help=t("ssc_help_watch_source"))
    parser.add_argument("--stdout", action="store_true", help=t("ssc_help_watch_stdout"))
    parser.add_argument("--hours", type=_hours, metavar="H", help=t("ssc_help_watch_hours"))
    parser.add_argument("--idle", action="store_true", help=t("ssc_help_watch_idle"))


def _source_warnings(requested: str, from_flag: bool) -> List[CliWarning]:
    from sofascore_scraper.config.settings import LIVE_DIRECT_WARNING
    from sofascore_scraper.services.live.supervisor import AVAILABLE_SOURCES

    warnings: List[CliWarning] = []
    if requested == "direct" and from_flag:  # yapılandırmadan gelen seçimi yükleyici zaten uyarır
        message = f"live.source is \"direct\": {LIVE_DIRECT_WARNING}."
        logger.warning(message)
        warnings.append(CliWarning("live_direct_source", message, logged=True))
    if requested not in AVAILABLE_SOURCES:
        message = (f"the live source {requested!r} is not available in this version; "
                   f"polling is used (the fallback of every source)")
        logger.warning(message)
        warnings.append(CliWarning("live_source_unavailable", message, logged=True))
    return warnings


def _scope(args: argparse.Namespace, store: Any) -> Any:
    from sofascore_scraper.services.live.supervisor import explicit_scope, scope_from_follows

    sports = [s.strip().lower() for s in args.sports or () if s.strip()]
    if args.event_ids or args.tournament_ids:
        if not sports:
            raise UsageError("--event and --tournament need --sport")
        return explicit_scope(sports, event_ids=args.event_ids or (), tournament_ids=args.tournament_ids or ())
    # `--sport` süzgeci kapsamın içinde taşınır: servis takipleri yeniden okurken de yalnızca bu sporları alır
    return scope_from_follows(store.follows.list(enabled=True), sports)


def _start_thread(target: Any, name: str) -> threading.Thread:
    thread = threading.Thread(target=target, name=name, daemon=True)
    thread.start()
    return thread


@command("watch", help="ssc_help_cmd_watch", description="ssc_desc_watch", configure=_arguments, settings=True)
def watch(inv: Invocation) -> CommandResult:
    args = inv.args
    if args.stdout and inv.out.mode == JSON:
        raise UsageError("--stdout writes a stream of lines; use it without --json (or with --output ndjson)")

    from sofascore_scraper import sinks
    from sofascore_scraper.config import loader
    from sofascore_scraper.services.live.supervisor import SCOPE_RELOAD_SECONDS, LiveService
    from sofascore_scraper.store import open_store

    settings = loader.active_settings()
    data_dir = os.path.abspath(settings.storage.data_dir)
    requested = args.source or settings.live.source
    warnings = _source_warnings(requested, from_flag=args.source is not None)

    store = open_store(data_dir)
    scope = _scope(args, store)
    if scope.skipped:
        message = f"these follows cannot be watched live and are skipped: {', '.join(scope.skipped)}"
        logger.warning(message)
        warnings.append(CliWarning("live_follow_skipped", message, logged=True))
    if scope.empty:
        if not args.idle:
            raise UsageError("nothing to watch: follow something with live = true, or give --sport with --event or "
                             "--tournament")
        # Kapsam takiplerden okundu (açık kapsam boş olamaz): servis onu SCOPE_RELOAD_SECONDS'ta bir yeniden okur
        message = (f"nothing to watch yet: no follow has live = true; waiting (--idle), the follows are read again "
                   f"every {SCOPE_RELOAD_SECONDS:.0f} s")
        logger.warning(message)
        warnings.append(CliWarning("live_nothing_to_watch", message, logged=True))

    dispatcher = sinks.dispatcher_for(store, settings.sinks)  # bozuk sink ayarı: config_invalid (çıkış kodu 2)
    service = LiveService(
        store, scope, poll_interval=settings.live.poll_interval_seconds,
        max_event_polls=settings.live.max_event_polls, requested_source=requested, **SERVICE_OPTIONS,
    )

    stop = threading.Event()
    threads: List[threading.Thread] = []
    follower = None
    if args.stdout:
        inv.out.mode = TEXT  # stdout olay satırlarınındır; özet stderr'e gider
        follower = sinks.Dispatcher(store, [sinks.StdoutSink("stdout", write=inv.out.write)])
        follower.step()  # konum "şimdi": servisin ilk olayından önce
        threads.append(_start_thread(lambda: follower.follow(stop), "watch-stdout"))
    if dispatcher is not None:
        dispatcher.register()  # yeni sink'in konumu "şimdi": servisin ilk olayından önce
        threads.append(_start_thread(lambda: dispatcher.run(stop), "watch-sinks"))

    previous = _install_sigterm(stop)
    interrupted = False
    try:
        service.run(stop, until_seconds=args.hours * 3600 if args.hours else None)
        interrupted = stop.is_set()  # SIGTERM
    except KeyboardInterrupt:
        interrupted = True
    finally:
        stop.set()
        _restore_sigterm(previous)
        stuck = set()
        for thread in threads:
            thread.join(SINK_JOIN_SECONDS if thread.name == "watch-sinks" else STDOUT_JOIN_SECONDS)
            if thread.is_alive():
                stuck.add(thread.name)
                logger.warning("The %s thread did not stop in time; leaving it behind", thread.name)
        if dispatcher is not None:
            if "watch-sinks" in stuck:
                dispatcher.close()
            else:
                # Durdurma, dağıtıcı `sinks` kilidini almadan gelmiş olabilir: birikenler (kilit boşsa) en çok
                # 10 sn teslim edilir; kilit başka bir süreçteyse (serve) onlar orada kalır
                sinks.drain_at_exit(dispatcher)
        if follower is not None and "watch-stdout" not in stuck:
            follower.close()  # `follow` dururken son olayları da yazmıştır (servis durdurmadan önce bitti)

    report = service.report
    data = {**report.to_dict(), "requested_source": requested, "data_dir": data_dir, "interrupted": interrupted}
    text = inv.t("ssc_watch_summary", rounds=report.rounds, requests=report.requests, events=report.events,
                 confirmed=report.confirmed)
    if args.stdout:
        return CommandResult(warnings=warnings, notes=[text])
    return CommandResult(data=data, text=text, warnings=warnings)


def _install_sigterm(stop: threading.Event) -> Optional[Any]:
    """SIGTERM (systemd, docker stop) servisi Ctrl+C gibi durdurur. Yalnızca ana thread'de kurulabilir."""
    if threading.current_thread() is not threading.main_thread() or not hasattr(signal, "SIGTERM"):
        return None
    try:
        return signal.signal(signal.SIGTERM, lambda signum, frame: stop.set())
    except (ValueError, OSError):
        return None


def _restore_sigterm(previous: Optional[Any]) -> None:
    if previous is None:
        return
    try:
        signal.signal(signal.SIGTERM, previous)
    except (ValueError, OSError):
        pass


__all__ = ["SOURCES"]
